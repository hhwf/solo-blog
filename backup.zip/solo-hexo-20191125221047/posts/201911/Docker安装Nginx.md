title: Docker安装Nginx
date: '2019-11-24 17:35:49'
updated: '2019-11-24 17:35:49'
tags: [docker, nginx]
permalink: /articles/2019/11/24/1574588149064.html
---
1、我们现在本地建立几个文件，用于存放 nginx 的配置文件等
```shell
#创建目录
mkdir /usr/local/nginx/{conf,logs,www}
```
- usr/local/nginx/conf 存放 nginx 配置文件
- usr/local/nginx/log 存放 nginx 日志
- usr/local/nginx/www 存放 nginx 访问的资源文件

2、启动Nginx
```
 docker run --name nginx -p 80:80 -d --rm nginx
```

3、导出配置文件
```
 docker cp nginx:/etc/nginx/nginx.conf /usr/local/nginx/conf/nginx.conf
 docker cp nginx:/etc/nginx/conf.d /usr/local/nginx/conf/conf.d
```
4、关闭nginx
```
docker stop nginx
```
会删除刚刚创建的容器

5、重新启动镜像
```
docker run -d -p 80:80 --name nginx \
 -v /usr/local/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
 -v /usr/local/nginx/conf/conf.d:/etc/nginx/conf.d \
 -v /usr/local/nginx/www:/usr/share/nginx/html \
 -v /usr/local/nginx/logs:/var/log/nginx nginx

```







